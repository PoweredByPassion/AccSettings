bash push.sh
PAUSE
