bash build.sh
PAUSE
